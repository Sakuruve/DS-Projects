import scrapy
from scrapy import Request

class CraigadsSpider(scrapy.Spider):
    name = 'craigads'
    allowed_domains = ['seattle.craigslist.org']
    start_urls = ['http://seattle.craigslist.org/search/est/cta/']

    def parse(self, response):
        craigads = response.xpath('//div[@class="result-info"]')
        
        for ad in craigads:
            title=ad.xpath('h3/a[@class="result-title hdrlnk"]/text()').extract_first()
            price=ad.xpath('span/span[@class="result-price"]/text()').extract_first()[1:-1]
            neighbourhood=ad.xpath('span/span[@class="result-hood"]/text()').extract_first()
            url=ad.xpath('h3/a/@href').extract_first()
            
            
            yield Request(url, callback=self.parse_page, dont_filter=True,
                          meta={'Title':title,'Price':price,'Neighbourhood':neighbourhood,'URL':url})
            
           
        
        rel_next_url = response.xpath('//span/a[@class="button next"]/@href').extract_first()
        abs_next_url = response.urljoin(rel_next_url)
        
        #To get adds of next pages
        yield Request(abs_next_url,callback=self.parse)
        
    def parse_page(self, response):
        title = response.meta['Title']
        price = response.meta.get('Price')
        neighbourhood = response.meta.get('Neighbourhood')
        url = response.meta.get('URL')
        content= response.xpath('//section[@id="postingbody"]/text()').extract()
        
        #Required Data
        yield {'Title': title, 'Price': price, 'Neighbourhood': neighbourhood, 'URL': url, 'Description': content}

